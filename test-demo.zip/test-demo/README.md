# Todoist API Automation
Automation tests for Todoist App API

## Prerequiste 

- Generate Todoist API Token from Settings->Integrations->API Token

- Update API Token in .env file

## Setup

- Clone this repository

- Change to project folder

    `cd project_folder`

- Change to project folder

    `cd project_folder`

- Install npm packages

    `npm install`
    
- Run test

    `npm run test`
    


