//endpoint 
const request = require('supertest');
const should = require('should');
const env = require('dotenv').config();
//jest json schema
const matchers  = require('jest-json-schema').matchers;
expect.extend(matchers);

const BASE_URL = process.env.TODOIST_BASE_URL;
const TOKEN = process.env.TODOIST_API_TOKEN;

const api = request(BASE_URL);


describe('Get all projects', function() {

    it('should require authorization', function(done) {
        api.get('/projects')
            .expect(400)
            .end(function(err, res) {
                if (err) return done(err);
                done();
            });
    });

    it('should respond with JSON array', function(done) {
        api.get('/projects')
            .set('Authorization', 'Bearer ' + TOKEN)
            .expect(200)
            .expect('Content-Type', /json/)
            .end(function(err, res) {
                if (err) return done(err);
                res.body.should.be.instanceof(Array);
                done();
            });
    });

});

describe('Create new project', function() {

    it('should require authorization', function(done) {
        api.post('/projects')
            .expect(400)
            .end(function(err, res) {
                if (err) return done(err);
                done();
            });
    });

    it('should create project', function(done) {
        api.post('/projects')
            .set('Authorization', 'Bearer ' + TOKEN)
            .send({"name": "Movies to watch"})
            .expect(200)
            .expect('Content-Type', /json/)
            .end(function(err, res) {
                if (err) return done(err);
                res.body.should.be.instanceof(Object);
                done();
            });
    });

});